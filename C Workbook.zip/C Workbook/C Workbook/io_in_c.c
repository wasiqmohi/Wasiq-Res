#include<stdio.h>

int main() {
  int num = 5;
  printf("Integer = %d\n", num);

  float num1 = 13.5;
  printf("Float = %f\n", num1);

  double num2 = 12.4;
  printf("Double = %lf\n", num2);

  char ch = 'a';
  printf("Character = %c", ch);

  return 0;
}