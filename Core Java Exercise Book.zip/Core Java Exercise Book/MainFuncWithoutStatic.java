public class MainFuncWithoutStatic {
  public void main(String[] args) {
    // Main function doesn't gets executed, error raised
    System.out.println("Hello world");
  }
}
