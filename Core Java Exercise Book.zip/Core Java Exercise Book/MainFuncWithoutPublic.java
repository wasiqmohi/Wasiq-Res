public class MainFuncWithoutPublic {
  static void main(String[] args) {
    // Main function doesn't gets executed, error raised
    System.out.println("Hello world");
  }
}
