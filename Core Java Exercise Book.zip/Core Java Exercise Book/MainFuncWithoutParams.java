public class MainFuncWithoutParams {
  public static void main() {
    // Main function doesn't gets executed, error raised
    System.out.println("Hello world");
  }
}
