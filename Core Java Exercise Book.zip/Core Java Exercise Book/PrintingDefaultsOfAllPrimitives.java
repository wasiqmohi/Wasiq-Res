public class PrintingDefaultsOfAllPrimitives {
  static int a;
  static char b;
  static boolean c;
  static byte d;
  static double e;
  static float f;
  static short g;
  static long h;
  public static void main(String[] args) {
    System.out.println("Integer: " + a);
    System.out.println("Character: '" + b + "'");
    System.out.println("Boolean: " + c);
    System.out.println("Byte: " + d);
    System.out.println("Double: " + e);
    System.out.println("Float: " + f);
    System.out.println("Short: " + g);
    System.out.println("Long: " + h);
  }
}
