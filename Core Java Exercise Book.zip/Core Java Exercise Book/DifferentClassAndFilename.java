/*
 * Code doesn't gets executed, returns error
 */

public class DifferentClassname {
  public static void main(String[] args) {
    System.out.println("Hello world");
  }
}
