// Java program to add 2 numbers

public class Addition {
  public static void main(String[] args) {
    int a = 100;
    int b = 200;
    int sum = a+b;
    System.out.println(a + " + " + b + " = " + sum);
  }
}