public class SwitchCase {
  public static void main(String[] args) {
    int num = 2;

    switch (num) {
      case 1:
        System.out.println("Java");
        break;
      case 2:
        System.out.println("C");
        break;
      case 3:
        System.out.println("Python");
        break;
      case 4:
        System.out.println("ES6");
        break;
      default:
        System.out.println("Not Listed");
    }
  }
}
